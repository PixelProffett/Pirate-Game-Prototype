import pygame

image_directory = str("img/")

pygame.init()
clock = pygame.time.Clock()

screen = pygame.display.set_mode((800, 600))

player_normal = pygame.transform.scale(pygame.image.load(image_directory + "hero.png"), (100, 100))

player_use_sheet = []
for z in range (4):
	img = pygame.transform.scale(pygame.image.load(image_directory + "hero_use" + str(z) + ".png"), (100, 100))
	player_use_sheet.append(img)

player_use_sheet_flip = []
for z in range (4):
	img = pygame.transform.scale(pygame.transform.flip(pygame.image.load(image_directory + "hero_use" + str(z) + ".png"), True, False), (100, 100))
	player_use_sheet_flip.append(img)

axe_cooldown = int(10)
axe_image = pygame.image.load(image_directory + "copper_axe_use.png").convert_alpha()
axe_image = pygame.transform.scale(axe_image, (200, 200))
axe_image = pygame.transform.rotate(axe_image, 45)

# rotate sprite script
def rot_center(image, angle):
    """rotate an image while keeping its center and size"""
    orig_rect = image.get_rect()
    rot_image = pygame.transform.rotate(image, angle)
    rot_rect = orig_rect.copy()
    rot_rect.center = rot_image.get_rect().center
    rot_image = rot_image.subsurface(rot_rect).copy()
    return rot_image

axe_angles_left = []
for i in range (36):
	image = rot_center(pygame.transform.flip(axe_image, True, False), i * 10)
	axe_angles_left.append(image)

axe_angles_right = []
for i in range (36):
	image = rot_center(axe_image, i * 10)
	axe_angles_right.append(image)

running = bool(True)
use_animation_index = int(-1)
using = bool(False)
item_selected = str("axe")
use_dir = "left"
pos = tuple((100, 100))
while running:
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			running = False
		if event.type == pygame.KEYDOWN:
			if event.key == pygame.K_LEFT:
				using = True
				use_animation_index = -1
				use_dir = "left"
			if event.key == pygame.K_RIGHT:
				using = True
				use_animation_index = -1
				use_dir = "right"

	screen.fill((255, 255, 255))

	if using:
		if item_selected == "axe":
			if use_dir == "left":
				offset_x = 120
				offset_y = 70
				use_animation_index += 0.5
				if use_animation_index < 4:
					screen.blit(player_use_sheet[int(use_animation_index)], pos)
				else:
					screen.blit(player_normal, pos)
				if use_animation_index == 0:
					screen.blit(axe_angles_left[1], (pos[0] - offset_x, pos[1] - offset_y))
				elif use_animation_index == 0.5:
					screen.blit(axe_angles_left[2], (pos[0] - offset_x, pos[1] - offset_y))
				elif use_animation_index == 1:
					screen.blit(axe_angles_left[2], (pos[0] - offset_x, pos[1] - offset_y))
				elif use_animation_index == 1.5:
					screen.blit(axe_angles_left[3], (pos[0] - offset_x, pos[1] - offset_y))
				elif use_animation_index == 2:
					screen.blit(axe_angles_left[4], (pos[0] - offset_x, pos[1] - offset_y))
				elif use_animation_index == 2.5:
					screen.blit(axe_angles_left[5], (pos[0] - offset_x, pos[1] - offset_y))
				elif use_animation_index == 3:
					screen.blit(axe_angles_left[6], (pos[0] - offset_x, pos[1] - offset_y))
				elif use_animation_index == 3.5:
					screen.blit(axe_angles_left[7], (pos[0] - offset_x, pos[1] - offset_y))
				elif use_animation_index == 4:
					screen.blit(axe_angles_left[8], (pos[0] - offset_x, pos[1] - offset_y))
				if use_animation_index > 4:
					using = False
					use_animation_index = -1
			elif use_dir == "right":
				offset_x = 70
				offset_y = 70
				use_animation_index += 0.5
				if use_animation_index < 4:
					screen.blit(player_use_sheet_flip[int(use_animation_index)], (pos[0] - 12, pos[1]))
				else:
					screen.blit(player_normal, pos)
				if use_animation_index == 0:
					screen.blit(axe_angles_right[35], (pos[0] - offset_x, pos[1] - offset_y))
				elif use_animation_index == 0.5:
					screen.blit(axe_angles_right[34], (pos[0] - offset_x, pos[1] - offset_y))
				elif use_animation_index == 1:
					screen.blit(axe_angles_right[34], (pos[0] - offset_x, pos[1] - offset_y))
				elif use_animation_index == 1.5:
					screen.blit(axe_angles_right[33], (pos[0] - offset_x, pos[1] - offset_y))
				elif use_animation_index == 2:
					screen.blit(axe_angles_right[32], (pos[0] - offset_x, pos[1] - offset_y))
				elif use_animation_index == 2.5:
					screen.blit(axe_angles_right[31], (pos[0] - offset_x, pos[1] - offset_y))
				elif use_animation_index == 3:
					screen.blit(axe_angles_right[30], (pos[0] - offset_x, pos[1] - offset_y))
				elif use_animation_index == 3.5:
					screen.blit(axe_angles_right[29], (pos[0] - offset_x, pos[1] - offset_y))
				elif use_animation_index == 4:
					screen.blit(axe_angles_right[28], (pos[0] - offset_x, pos[1] - offset_y))
				if use_animation_index > 4:
					using = False
					use_animation_index = -1
	else:
		screen.blit(player_normal, pos)

	pygame.display.flip()
	clock.tick(60)
	pygame.display.set_caption(str(clock.get_fps()))
pygame.quit()