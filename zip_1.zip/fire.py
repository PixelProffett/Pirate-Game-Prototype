import pygame, random



pygame.init()
clock = pygame.time.Clock()

screen = pygame.display.set_mode((1240, 720))

def rot_center(image, angle):
    orig_rect = image.get_rect()
    rot_image = pygame.transform.rotate(image, angle)
    rot_rect = orig_rect.copy()
    rot_rect.center = rot_image.get_rect().center
    rot_image = rot_image.subsurface(rot_rect).copy()
    return rot_image

fire_particles = []
class Fire():
	def __init__(self, x, y, delta_y, delta_x):
		self.x = x
		self.y = y
		self.delta_y = delta_y + random.randint(0, 4)
		self.delta_x = delta_x + random.randint(0, 4)
		self.image = pygame.transform.scale(pygame.image.load("fire_" + str(random.randint(0, 2)) + ".png").convert_alpha(), (15, 15))
		self.alpha = 100
	def render(self, window):
		self.image = rot_center(self.image, 35)
		self.x += self.delta_x + random.randint(1, 5)
		self.y += self.delta_y - random.randint(1, 5)
		self.alpha -= random.randint(1, 5)
		self.image.set_alpha(self.alpha)
		window.blit(self.image, (self.x, self.y))

def drawFire(window):
	for fire_particle in fire_particles:
		fire_particle.render(window)
		if fire_particle.alpha < 0:
			fire_particles.remove(fire_particle)

running = True
while running:
	for x in range (4):
		fire_particles.append(Fire(500, 500, 0, 10))
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			running = False
		if event.type == pygame.KEYDOWN:
			if event.key == pygame.K_ESCAPE:
				running = False
	screen.fill((255, 255, 255))

	drawFire(screen)

	pygame.display.flip()
	pygame.display.set_caption(str(clock.get_fps()))
	clock.tick(60)
pygame.quit()