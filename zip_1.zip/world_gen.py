import pygame
from pygame.locals import *

image_directory = str("img/")

pygame.init()
clock = pygame.time.Clock()

screen_size = tuple((800, 600))
screen = pygame.display.set_mode(screen_size)

blocks = []
indicator1 = pygame.image.load(image_directory + "indicator_0.png").convert_alpha()
indicator1 = pygame.transform.scale(indicator1, (100, 100))
indicator2 = pygame.image.load(image_directory + "indicator_1.png").convert_alpha()
indicator2 = pygame.transform.scale(indicator2, (100, 100))

hit1 = pygame.image.load(image_directory + "hit_0.png").convert_alpha()
hit1 = pygame.transform.scale(hit1, (100, 100))
hit2 = pygame.image.load(image_directory + "hit_1.png").convert_alpha()
hit2 = pygame.transform.scale(hit2, (100, 100))
class Block():
	def __init__(self, x, y, id=0):
		self.image = pygame.image.load(image_directory + "block_" + str(id) + ".png").convert_alpha()
		self.image = pygame.transform.scale(self.image, (100, 100))
		self.x = x
		self.y = y
		self.indicator_frame = 0
		self.rect = pygame.Rect(self.x, self.y, 100, 100)
		self.health = 2
		self.hurt_cooldown = 0
	def render(self, window):
		if self.health > 0:
			from main import camera_x, camera_y, mouse_rect, using, inventory
			self.indicator_frame += 0.1
			if self.indicator_frame >= 2:
				self.indicator_frame = 0
			self.hurt_cooldown += 0.1
			self.rect = pygame.Rect(self.x + camera_x, self.y + camera_y, 100, 100)
			window.blit(self.image, (self.x + camera_x, self.y + camera_y))
			if self.rect.colliderect(mouse_rect):
				if not using:
					if self.indicator_frame <= 1:
						window.blit(indicator1, (self.x + camera_x, self.y + camera_y))
					if self.indicator_frame <= 2 and self.indicator_frame >= 1:
						window.blit(indicator2, (self.x + camera_x, self.y + camera_y))
				if using:
					if self.hurt_cooldown > 2:
						self.health -= 1
						self.hurt_cooldown = 0
						inventory.append("wood")
					if self.indicator_frame <= 1:
						window.blit(hit1, (self.x + camera_x, self.y + camera_y))
					if self.indicator_frame <= 2 and self.indicator_frame >= 1:
						window.blit(hit2, (self.x + camera_x, self.y + camera_y))

def draw_blocks(window):
	for block in blocks:
		block.render(window)

def Generate(structure, position):
	if structure == "tree":
		# leaves
		blocks.append(Block(position[0] * 100, position[1] * 100, 1))
		blocks.append(Block(position[0] * 100 + 100, position[1] * 100, 1))
		blocks.append(Block(position[0] * 100 + 200, position[1] * 100, 1))
		blocks.append(Block(position[0] * 100 + 100, position[1] * 100 - 100, 1))

		# logs
		blocks.append(Block(position[0] * 100 + 100, position[1] * 100 + 100, 0))
		blocks.append(Block(position[0] * 100 + 100, position[1] * 100 + 200, 0))
		blocks.append(Block(position[0] * 100 + 100, position[1] * 100 + 300, 0))

	elif structure == "":
		print("sadfgasdfsdfgukhlrmlns")

#Generate("tree", (1, 1))
#
#wood_sprite = pygame.image.load(image_directory + "block_0.png").convert_alpha()
#wood_sprite = pygame.transform.scale(wood_sprite, (100, 100))
#
#running = bool(True)
#while running:
#	for event in pygame.event.get():
#		if event.type == QUIT:
#			running = False
#	screen.fill((255, 255, 255))
#
#	draw_blocks(screen)
#
#	pygame.display.flip()
#	clock.tick(60)
#pygame.quit()