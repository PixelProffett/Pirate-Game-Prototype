import pygame
from pygame.locals import *
import random

pygame.init()
clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 30)

screen_size = tuple((800, 600))
screen = pygame.display.set_mode(screen_size)

slot_selected = int(1)
text_color = (0, 0, 0)

# slot variables --------------------------------
hotbar1_select = pygame.transform.scale(pygame.image.load("hotbar_select.png").convert_alpha(), (100, 100))
hotbar2_select = pygame.transform.scale(pygame.image.load("hotbar_select.png").convert_alpha(), (100, 100))
hotbar3_select = pygame.transform.scale(pygame.image.load("hotbar_select.png").convert_alpha(), (100, 100))
hotbar4_select = pygame.transform.scale(pygame.image.load("hotbar_select.png").convert_alpha(), (100, 100))

slot_1 = pygame.transform.scale(pygame.image.load("slot.png").convert_alpha(), (100, 100))
slot_2 = pygame.transform.scale(pygame.image.load("slot.png").convert_alpha(), (100, 100))
slot_3 = pygame.transform.scale(pygame.image.load("slot.png").convert_alpha(), (100, 100))
slot_4 = pygame.transform.scale(pygame.image.load("slot.png").convert_alpha(), (100, 100))

slot_1_item = pygame.transform.scale(pygame.image.load("nothing.png").convert_alpha(), (95, 95))
slot_2_item = pygame.transform.scale(pygame.image.load("nothing.png").convert_alpha(), (95, 95))
slot_3_item = pygame.transform.scale(pygame.image.load("nothing.png").convert_alpha(), (95, 95))
slot_4_item = pygame.transform.scale(pygame.image.load("nothing.png").convert_alpha(), (95, 95))

slot_1_amt = int(0)
slot_2_amt = int(0)
slot_3_amt = int(0)
slot_4_amt = int(0)

slot_1_amt_text = font.render(str(slot_1_amt), True, text_color)
slot_2_amt_text = font.render(str(slot_2_amt), True, text_color)
slot_3_amt_text = font.render(str(slot_3_amt), True, text_color)
slot_4_amt_text = font.render(str(slot_4_amt), True, text_color)

slot_pos = tuple((50, 100))
slot_item_offset = float(10.0)
hud_update_delay = int(3)
# -----------------------------------------------

in_game_items = 4
items = []
for item123 in range (in_game_items):
	item = pygame.image.load("block_" + str(item123) + ".png").convert_alpha()
	item = pygame.transform.scale(item, (80, 80))
	items.append(item)

# testing out the variables
slot_1_item = items[1]
slot_1_amt = 1024
slot_3_item = items[3]
slot_3_amt = 1

running = bool(True)
while running:
	hud_update_delay -= 1

	if hud_update_delay <= 0:
		slot_1_amt_text = font.render(str(slot_1_amt), True, text_color)
		slot_2_amt_text = font.render(str(slot_2_amt), True, text_color)
		slot_3_amt_text = font.render(str(slot_3_amt), True, text_color)
		slot_4_amt_text = font.render(str(slot_4_amt), True, text_color)

		hud_update_delay = 5

	for event in pygame.event.get():
		if event.type == QUIT:
			running = False
		if event.type == MOUSEWHEEL:
			if event.y > 0:
				slot_selected += 1
				if slot_selected > 4:
					slot_selected = 1
			if event.y < 0:
				slot_selected -= 1
				if slot_selected < 1:
					slot_selected = 4
		

	screen.fill((255, 255, 255))

	screen.blit(slot_1, slot_pos)
	screen.blit(slot_2, (slot_pos[0] + 150, slot_pos[1]))
	screen.blit(slot_3, (slot_pos[0] + 300, slot_pos[1]))
	screen.blit(slot_4, (slot_pos[0] + 450, slot_pos[1]))

	if slot_selected == 1:
		screen.blit(hotbar1_select, slot_pos)
	elif slot_selected == 2:
		screen.blit(hotbar2_select, (slot_pos[0] + 150, slot_pos[1]))
	elif slot_selected == 3:
		screen.blit(hotbar3_select, (slot_pos[0] + 300, slot_pos[1]))
	elif slot_selected == 4:
		screen.blit(hotbar4_select, (slot_pos[0] + 450, slot_pos[1]))

	screen.blit(slot_1_item, (slot_pos[0] + slot_item_offset, slot_pos[1] + slot_item_offset))
	screen.blit(slot_2_item, (slot_pos[0] + 150 + slot_item_offset, slot_pos[1] + slot_item_offset))
	screen.blit(slot_3_item, (slot_pos[0] + 300 + slot_item_offset, slot_pos[1] + slot_item_offset))
	screen.blit(slot_4_item, (slot_pos[0] + 450 + slot_item_offset, slot_pos[1] + slot_item_offset))

	screen.blit(slot_1_amt_text, (slot_pos[0] + 90, slot_pos[1] + 90))
	screen.blit(slot_2_amt_text, (slot_pos[0] + 150 + 90, slot_pos[1] + 90))
	screen.blit(slot_3_amt_text, (slot_pos[0] + 300 + 90, slot_pos[1] + 90))
	screen.blit(slot_4_amt_text, (slot_pos[0] + 450 + 90, slot_pos[1] + 90))

	pygame.display.flip()
	clock.tick(60)
pygame.quit()