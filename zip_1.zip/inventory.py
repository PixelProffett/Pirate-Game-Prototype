import pygame
from pygame.locals import *
import random

# todo
#
# make the scroll sidebar appear when you press "E"

pygame.init()
clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 30)

screen_size = tuple((800, 600))
screen = pygame.display.set_mode(screen_size)

pressing_e = bool(False)
e_text = font.render(str(pressing_e), True, (0, 255, 0), (0, 0, 0))

scrolls = []
class Scroll_sidebar():
	def __init__(self, x, y, type="tile"):
		self.x = x
		self.y = y
		if type == "tile":
			self.image = pygame.transform.scale(pygame.image.load("scroll_0.png").convert_alpha(), (100, 100))
		elif type == "edge":
			self.image = pygame.transform.scale(pygame.image.load("scroll_1.png").convert_alpha(), (100, 100))
	def render(self, window):
		window.blit(self.image, (self.x, self.y))
def draw_sidebar(window):
	for scroll in scrolls:
		scroll.render(window)

running = bool(True)
while running:
	e_text = font.render(str(pressing_e), True, (0, 255, 0), (0, 0, 0))
		
	for event in pygame.event.get():
		if event.type == QUIT:
			running = False
		if event.type == KEYDOWN:
			if event.key == K_e:
				pressing_e = True
		if event.type == KEYUP:
			if event.key == K_e:
				pressing_e = False

	screen.fill((255, 255, 255))
	
	screen.blit(e_text, (0, 0))

	pygame.display.update()
	pygame.display.set_caption(str(round(clock.get_fps())))	
	clock.tick(60)
pygame.quit()