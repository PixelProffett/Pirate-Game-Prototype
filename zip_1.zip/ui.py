import pygame

pygame.init()
pygame.font.init()
clock = pygame.time.Clock()

ui_font = pygame.font.Font("Finger Printed.ttf", 30)

#screen = pygame.display.set_mode((1920, 1080), pygame.FULLSCREEN)

ui_health_text = 0
health = 19

def ui_init():
	global ui_font;global ui_health_text;global health
	ui_health_text = ui_font.render(str(health), True, (0, 0, 0))
	return ui_health_text

def ui_update(window):
	image_directory = str("img/")
	ui_health_text_image = pygame.transform.scale(pygame.image.load(image_directory + "health_text.png").convert_alpha(), (400, 200))
	global ui_health_text
	window.blit(ui_health_text_image, (0, 0), special_flags = pygame.BLEND_ALPHA_SDL2)
	window.blit(ui_health_text, (400, 10))

#ui_init()

#running = bool(True)
#while running:
#	for event in pygame.event.get():
#		if event.type == pygame.QUIT:
#			running = False
#		if event.type == pygame.KEYDOWN:
#			if event.key == pygame.K_ESCAPE:
#				running = False
#	screen.fill((255, 255, 255))
#
#	ui_update()
#
#	pygame.display.flip()
#	clock.tick(60)
#pygame.quit()