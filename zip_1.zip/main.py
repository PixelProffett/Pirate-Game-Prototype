import pygame, random

# import other files
import ui
from ui import *;from ui import ui_init, ui_update
import world_gen
from world_gen import Block, blocks, draw_blocks

# ----------TODO---------- #
# impliment shadows for the grass class

image_directory = str("img/")
shade_directory = str("shading/")

pygame.init()
pygame.font.init()
clock = pygame.time.Clock()

font = pygame.font.Font("COUR.TTF", 30)

#print("how big do you want the screen to be?")
#print("1. 1920 x 1080")
#print("2. 1240 x 720")
#screen_size_input = input(">>>")
screen_size = tuple(((1920, 1080)))
screen = pygame.display.set_mode(screen_size, pygame.FULLSCREEN, depth=0, display=0, vsync=1)
player_normal = pygame.transform.scale(pygame.image.load(image_directory + "hero.png").convert_alpha(), (100, 100))

sprite_sheet_right = []
sprite_sheet_left = []
sprite_sheet_down = []
sprite_sheet_up = []
for a in range (4):
	sprite_sheet_right.append(pygame.transform.scale(pygame.image.load(image_directory + "hero_right" + str(a) + ".png"), (100, 100)))
for b in range (4):
	sprite_sheet_left.append(pygame.transform.scale(pygame.image.load(image_directory + "hero_left" + str(b) + ".png"), (100, 100)))
for c in range (4):
	sprite_sheet_down.append(pygame.transform.scale(pygame.image.load(image_directory + "hero_down" + str(c) + ".png"), (100, 100)))
for d in range (4):
	sprite_sheet_up.append(pygame.transform.scale(pygame.image.load(image_directory + "hero_up" + str(d) + ".png"), (100, 100)))

player_use_sheet = []
for z in range (4):
	img = pygame.transform.scale(pygame.image.load(image_directory + "hero_use" + str(z) + ".png"), (100, 100))
	player_use_sheet.append(img)

player_use_sheet_flip = []
for z in range (4):
	img = pygame.transform.scale(pygame.transform.flip(pygame.image.load(image_directory + "hero_use" + str(z) + ".png"), True, False), (100, 100))
	player_use_sheet_flip.append(img)

no_sprite = pygame.image.load(image_directory + "no_sprite.png")

player_x = screen.get_width() / 2 - 50
player_y = screen.get_height() / 2 - 50
player_rect = pygame.Rect(player_x, player_y, 50, 50)
camera_x = 0
camera_y = 0
camera_speed = float(5.0)

# inventory
inventory = []

# walking variables
walking_left = False
walking_right = False
walking_up = False
walking_down = False

# mouse variables
mouse_x = pygame.mouse.get_pos()[0]
mouse_y = pygame.mouse.get_pos()[1]
mouse_x_text = font.render(str(mouse_x), False, (0, 255, 0), (0, 0, 0))
mouse_y_text = font.render(str(mouse_y), False, (0, 255, 0), (0, 0, 0))
pygame.mouse.set_cursor(pygame.cursors.tri_left)
mouse_rect = pygame.Rect(mouse_x, mouse_y, 45, 45)

# debug
fps = clock.get_fps()
fps_text = font.render(str(fps), False, (0, 255, 0), (0, 0, 0))
player_x_text = font.render(str(player_x), False, (0, 255, 0), (0, 0, 0))
player_y_text = font.render(str(player_y), False, (0, 255, 0), (0, 0, 0))

# axe stuff
axe_cooldown = int(10)
axe_image = pygame.image.load(image_directory + "copper_axe_use.png").convert_alpha()
axe_image = pygame.transform.scale(axe_image, (200, 200))
axe_image = pygame.transform.rotate(axe_image, 45)
using = False
used = bool(False)

# rotate sprite script
def rot_center(image, angle):
    """rotate an image while keeping its center and size"""
    orig_rect = image.get_rect()
    rot_image = pygame.transform.rotate(image, angle)
    rot_rect = orig_rect.copy()
    rot_rect.center = rot_image.get_rect().center
    rot_image = rot_image.subsurface(rot_rect).copy()
    return rot_image

axe_angles_left = []
for i in range (36):
	image = rot_center(pygame.transform.flip(axe_image, True, False), i * 10)
	axe_angles_left.append(image)

axe_angles_right = []
for i in range (36):
	image = rot_center(axe_image, i * 10)
	axe_angles_right.append(image)


# sword stuff
sword_cooldown = int(10)
sword_image = pygame.image.load(image_directory + "sword_use.png").convert_alpha()
sword_image = pygame.transform.scale(sword_image, (200, 200))
sword_image = pygame.transform.rotate(sword_image, 45)
using = False
used = bool(False)

# rotate sprite script
def rot_center(image, angle):
    """rotate an image while keeping its center and size"""
    orig_rect = image.get_rect()
    rot_image = pygame.transform.rotate(image, angle)
    rot_rect = orig_rect.copy()
    rot_rect.center = rot_image.get_rect().center
    rot_image = rot_image.subsurface(rot_rect).copy()
    return rot_image

sword_angles_left = []
for i in range (36):
	image = rot_center(pygame.transform.flip(sword_image, True, False), i * 10)
	sword_angles_left.append(image)

sword_angles_right = []
for i in range (36):
	image = rot_center(sword_image, i * 10)
	sword_angles_right.append(image)

vignette = pygame.image.load(image_directory + "vignette.png").convert_alpha()
vignette = pygame.transform.scale(vignette, screen_size)
	
# tree script
trees = []
class Tree():
	def __init__(self, x, y):
		self.x = x
		self.y = y
		self.randomiser = random.randint(1, 3)
		if self.randomiser <= 3:
			self.image = pygame.image.load(image_directory + "palm_tree1.png").convert_alpha()
			self.outline = pygame.image.load(image_directory + "palm_tree_outline.png").convert_alpha()
			self.shade = pygame.image.load(shade_directory + "palm_tree1shadow.png").convert_alpha()
		self.image = pygame.transform.scale(self.image, (120, 200))	
		self.outline = pygame.transform.scale(self.outline, (120, 200))
		self.shade = pygame.transform.scale(self.shade, (120 * 2, 200 * 2))
		self.shade.set_alpha(150)
		self.health = 5
		self.rect = pygame.Rect(self.x, self.y, 100, 200)
		
	def render(self):
		global player_rect
		global tree_hit_cooldown
		global trees
		global axe_cooldown
		global using
		global used
		global mouse_rect
		self.rect = pygame.Rect(self.x + camera_x, self.y + camera_y, 100, 200)
		#awpygame.draw.rect(screen, (255, 0, 0), self.rect)
		screen.blit(self.image, (self.x + camera_x, self.y + camera_y))
		screen.blit(self.shade, (self.x + camera_x, self.y + 200 + camera_y))
		#if self.rect.colliderect(mouse_rect):
		screen.blit(self.outline, (self.x, self.y))
		if self.rect.colliderect(mouse_rect) and used == True:
			self.health -= 1
			used = False
		
def drawTrees():
	for tree in trees:
		tree.render()
		if tree.health <= 0:
			trees.remove(tree)

# grass script
grasses = []
class Grass():
	def __init__(self, x, y):
		self.x = x
		self.y = y
		self.randomiser = random.randint(1, 3)
		if self.randomiser <= 3:
			self.image = pygame.image.load(image_directory + "grass.png").convert_alpha()
			self.shade = pygame.image.load(shade_directory + "grass_shade.png").convert_alpha()
		self.image = pygame.transform.scale(self.image, (100, 100))
		self.shade = pygame.transform.scale(self.shade, (120, 100))

	def render(self):
		self.asdf = float(self.y) + 100
		screen.blit(self.image, (float(self.x) + float(camera_x), float(self.y) + float(camera_y)))
		screen.blit(self.shade, (float(self.x) + float(camera_x), (self.asdf) + float(camera_y)))

def drawGrass():
	for grass in grasses:
		grass.render()


def Create(entity, pos):
	if entity == "Tree()":
		trees.append(Tree(pos[0], pos[1]))
	elif entity == "Grass()":
		trees.append(Grass(pos[0], pos[1]))

# shipwreck shore trees, rocks and grass
Create("Tree()", (520.0, 2340.0))
Create("Tree()", (760.0, 1920.0))
Create("Tree()", (1030.0, 2120.0))
Create("Tree()", (900.0, 2450.0))
Create("Tree()", (1110.0, 2400.0))
Create("Tree()", (1300.0, 2480.0))
grasses = [Grass('1690.0', '2190.0'), Grass('2240.0', '2600.0'), Grass('2240.0', '2310.0'), Grass('1370.0', '1660.0'), Grass('2000.0', '1390.0'), Grass('890.0', '930.0'), Grass('1150.0', '700.0'), Grass('1370.0', '880.0'), Grass('1170.0', '1110.0'), Grass('530.0', '1650.0'), Grass('390.0', '1530.0'), Grass('530.0', '1360.0'), Grass('620.0', '1540.0'), Grass('400.0', '1760.0'), Grass('2380.0', '780.0'), Grass('1860.0', '760.0'), Grass('1690.0', '590.0')]

wall_rect = pygame.Rect(100, 100, 50, 50)

running = True
animation_index = int(0)
item_anim_frame = int(0)
tree_hit_cooldown = int(30)
use_animation_index = int(-1)
using = bool(False)
item_selected = str("axe")
use_dir = "left"
pos = tuple((100, 100))
offset_x = int(0)
offset_y = int(0)
debug = bool(False)

# a list of places that the player has pressed the "pos" key
positions = []

# initialise the ui
ui_init()

vignette.set_alpha(50)



while running:
	screen.fill((0, 162, 232))
	draw_blocks(screen)
	# shipwreck shore
	pygame.draw.polygon(screen, (0, 255, 0),
					 					[
											(250 * 3 + camera_x, 970 * 3 + camera_y),
										    (530 * 3 + camera_x, 1000 * 3 + camera_y),
											(840 * 3 + camera_x, 960 * 3 + camera_y),
											(870 * 3 + camera_x, 750 * 3 + camera_y),
											(700 * 3 + camera_x, 650 * 3 + camera_y),
											(750 * 3 + camera_x, 550 * 3 + camera_y),
											(900 * 3 + camera_x, 400 * 3 + camera_y),
											(840 * 3 + camera_x, 200 * 3 + camera_y),
											(700 * 3 + camera_x, 250 * 3 + camera_y),
											(600 * 3 + camera_x, 140 * 3 + camera_y),
											(320 * 3 + camera_x, 200 * 3 + camera_y),
											(250 * 3 + camera_x, 400 * 3 + camera_y),
											(30 * 3 + camera_x, 480 * 3 + camera_y),
											(00 * 3 + camera_x, 770 * 3 + camera_y)
										]
									)

	drawGrass()

	#screen.blit(vignette, (0, 0))
	wall_rect = pygame.Rect(100 + camera_x, 100 + camera_y, 50, 50)
	pygame.draw.rect(screen, (0, 0, 0), wall_rect)

	mouse_rect = pygame.Rect(mouse_x, mouse_y, 1, 1)
	#pygame.draw.rect(screen, (255, 0, 0), mouse_rect)
	mouse_x = pygame.mouse.get_pos()[0]
	mouse_y = pygame.mouse.get_pos()[1]
	mouse_x_text = font.render(str(mouse_x), True, (0, 255, 0), (0, 0, 0))
	mouse_y_text = font.render(str(mouse_y), True, (0, 255, 0), (0, 0, 0))
	if mouse_x < 962:
		pygame.mouse.set_cursor(pygame.cursors.tri_left)
	if mouse_x > 962:
		pygame.mouse.set_cursor(pygame.cursors.tri_right)

	if tree_hit_cooldown > 0:
		tree_hit_cooldown -= 1
	else:
		tree_hit_cooldown = int(30)
	animation_index += 0.3
	player_rect = pygame.Rect(player_x + 20 + camera_x, player_y + 14 + camera_y, 48, 90)

	if animation_index > 3:
		animation_index = 0

	if axe_cooldown > 0:
		axe_cooldown -= 1

	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			running = False
		if event.type == pygame.KEYDOWN:
			if event.key == pygame.K_LCTRL:
				debug = True
			if event.key == pygame.K_d:
				walking_right = True
			if event.key == pygame.K_a:
				walking_left = True
			if event.key == pygame.K_w:
				walking_up = True
			if event.key == pygame.K_s:
				walking_down = True
			if event.key == pygame.K_ESCAPE:
				running = False
			if event.key == pygame.K_1:
				item_selected = "axe"
			if event.key == pygame.K_2:
				item_selected = "sword"
			if event.key == pygame.K_e:
				print(inventory)
				print(inventory.count("wood"))
			if event.key == pygame.K_p:
				positions.append((str(player_x), str(player_y)))
		if event.type == pygame.MOUSEBUTTONDOWN:
			if event.button == pygame.BUTTON_LEFT:
				if axe_cooldown == 0:
					if mouse_x < 962:
						using = True
						use_animation_index = -1
						use_dir = "left"
					if mouse_x > 962:
						using = True
						use_animation_index = -1
						use_dir = "right"	
					axe_cooldown = 30
		if event.type == pygame.KEYUP:
			if event.key == pygame.K_LCTRL:
				debug = False
			if event.key == pygame.K_d:
				walking_right = False
			if event.key == pygame.K_a:
				walking_left = False
			if event.key == pygame.K_w:
				walking_up = False
			if event.key == pygame.K_s:
				walking_down = False

	#pygame.draw.rect(screen, (255, 0, 0), player_rect)

	if using == False:
		if walking_up:
			screen.blit(sprite_sheet_up[int(animation_index)], (player_x + camera_x, player_y + camera_y))
		elif walking_right:
			screen.blit(sprite_sheet_right[int(animation_index)], (player_x + camera_x, player_y + camera_y))
		elif walking_left:
			screen.blit(sprite_sheet_left[int(animation_index)], (player_x + camera_x, player_y + camera_y))
		elif walking_down:
			screen.blit(sprite_sheet_down[int(animation_index)], (player_x + camera_x, player_y + camera_y))

		if walking_down == False and walking_up == False and walking_right == False and walking_left == False:
			screen.blit(player_normal, (player_x + camera_x, player_y + camera_y))

	if walking_up:
		camera_y += camera_speed * 2
		player_y -= camera_speed * 2
	if walking_right:
		camera_x -= camera_speed * 2
		player_x += camera_speed * 2
	if walking_left:
		camera_x += camera_speed * 2
		player_x -= camera_speed * 2
	if walking_down:
		camera_y -= camera_speed * 2
		player_y += camera_speed * 2

	if using:
		if item_selected == "axe":
			if use_dir == "left":
				offset_x = -120
				offset_y = -70
				use_animation_index += 0.5
				if use_animation_index < 4:
					screen.blit(player_use_sheet[int(use_animation_index)], (player_x + camera_x, player_y + camera_y))
				else:
					screen.blit(player_normal, (player_x + camera_x, player_y + camera_y))
				if use_animation_index == 0:
					screen.blit(axe_angles_left[1], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				elif use_animation_index == 0.5:
					screen.blit(axe_angles_left[2], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				elif use_animation_index == 1:
					screen.blit(axe_angles_left[2], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				elif use_animation_index == 1.5:
					screen.blit(axe_angles_left[3], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				elif use_animation_index == 2:
					screen.blit(axe_angles_left[4], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				elif use_animation_index == 2.5:
					screen.blit(axe_angles_left[5], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				elif use_animation_index == 3:
					screen.blit(axe_angles_left[6], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				elif use_animation_index == 3.5:
					screen.blit(axe_angles_left[7], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				elif use_animation_index == 4:
					screen.blit(axe_angles_left[8], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				if use_animation_index > 4:
					using = False
					use_animation_index = -1
					used = True
			elif use_dir == "right":
				offset_x = -70
				offset_y = -70
				use_animation_index += 0.5
				if use_animation_index < 4:
					screen.blit(player_use_sheet_flip[int(use_animation_index)], (player_x + camera_x - 12, player_y + camera_y))
				else:
					screen.blit(player_normal, (player_x + camera_x, player_y + camera_y))
				if use_animation_index == 0:
					screen.blit(axe_angles_right[35], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				elif use_animation_index == 0.5:
					screen.blit(axe_angles_right[34], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				elif use_animation_index == 1:
					screen.blit(axe_angles_right[34], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				elif use_animation_index == 1.5:
					screen.blit(axe_angles_right[33], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				elif use_animation_index == 2:
					screen.blit(axe_angles_right[32], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				elif use_animation_index == 2.5:
					screen.blit(axe_angles_right[31], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				elif use_animation_index == 3:
					screen.blit(axe_angles_right[30], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				elif use_animation_index == 3.5:
					screen.blit(axe_angles_right[29], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				elif use_animation_index == 4:
					screen.blit(axe_angles_right[28], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				if use_animation_index > 4:
					using = False
					use_animation_index = -1
					used = True
		if item_selected == "sword":
			if use_dir == "left":
				offset_x = -120
				offset_y = -70
				use_animation_index += 0.5
				if use_animation_index < 4:
					screen.blit(player_use_sheet[int(use_animation_index)], (player_x + camera_x, player_y + camera_y))
				else:
					screen.blit(player_normal, (player_x + camera_x, player_y + camera_y))
				if use_animation_index == 0:
					screen.blit(sword_angles_left[1], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				elif use_animation_index == 0.5:
					screen.blit(sword_angles_left[2], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				elif use_animation_index == 1:
					screen.blit(sword_angles_left[2], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				elif use_animation_index == 1.5:
					screen.blit(sword_angles_left[3], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				elif use_animation_index == 2:
					screen.blit(sword_angles_left[4], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				elif use_animation_index == 2.5:
					screen.blit(sword_angles_left[5], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				elif use_animation_index == 3:
					screen.blit(sword_angles_left[6], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				elif use_animation_index == 3.5:
					screen.blit(sword_angles_left[7], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				elif use_animation_index == 4:
					screen.blit(sword_angles_left[8], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				if use_animation_index > 4:
					using = False
					use_animation_index = -1
					used = True
			elif use_dir == "right":
				offset_x = -70
				offset_y = -70
				use_animation_index += 0.5
				if use_animation_index < 4:
					screen.blit(player_use_sheet_flip[int(use_animation_index)], (player_x + camera_x - 12, player_y + camera_y))
				else:
					screen.blit(player_normal, (player_x + camera_x, player_y + camera_y))
				if use_animation_index == 0:
					screen.blit(sword_angles_right[35], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				elif use_animation_index == 0.5:
					screen.blit(sword_angles_right[34], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				elif use_animation_index == 1:
					screen.blit(sword_angles_right[34], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				elif use_animation_index == 1.5:
					screen.blit(sword_angles_right[33], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				elif use_animation_index == 2:
					screen.blit(sword_angles_right[32], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				elif use_animation_index == 2.5:
					screen.blit(sword_angles_right[31], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				elif use_animation_index == 3:
					screen.blit(sword_angles_right[30], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				elif use_animation_index == 3.5:
					screen.blit(sword_angles_right[29], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				elif use_animation_index == 4:
					screen.blit(sword_angles_right[28], (player_x + offset_x + camera_x, player_y + offset_y + camera_y))
				if use_animation_index > 4:
					using = False
					use_animation_index = -1
					used = True
	#else:
	#	screen.blit(player_normal, (player_x + offset_x, player_y + offset_y))

	ui_update(screen)
	drawTrees()

	# debug
	if debug == True:
		screen_size = screen.get_size()
		fps = round(clock.get_fps(), 1)
		fps_length = len(str(fps))
		fps_text = font.render(str(fps), False, (0, 255, 0), (0, 0, 0))
		player_x_text = font.render(str(player_x), True, (0, 255, 0), (0, 0, 0))
		player_y_text = font.render(str(player_y), True, (0, 255, 0), (0, 0, 0))
		screen.blit(mouse_x_text, (mouse_x + 10, mouse_y + 10))
		screen.blit(mouse_y_text, (mouse_x + 10, mouse_y + 40))
		screen.blit(player_x_text, (screen_size[0] / 2, screen_size[1] / 2))
		screen.blit(player_y_text, (screen_size[0] / 2, screen_size[1] / 2 + 30))
		screen.blit(fps_text, (screen_size[0] - (fps_length * 10), 0))
		pygame.draw.line(screen, (0, 0, 0), (screen_size[0] / 2, 0), (screen_size[0] / 2, screen_size[1]))
		pygame.draw.line(screen, (0, 0, 0), (0, screen_size[1] / 2), (screen_size[0], screen_size[1] / 2))

	pygame.display.flip()
	clock.tick(60)
print(positions)
pygame.quit()